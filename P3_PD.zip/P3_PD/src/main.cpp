//1.
#include <WiFi.h>
#include <WebServer.h>

// SSID & Password
const char* ssid = "Nautilus"; // Enter your SSID here
const char* password = "20000Leguas"; // Enter your Password here

WebServer server(80); // Object of WebServer(HTTP port, 80 is default)

// Declaración de la función antes de su uso
void handle_root();

void setup() {
  Serial.begin(115200);
  Serial.println("Try Connecting to ");
  Serial.println(ssid);

  // Connect to your Wi-Fi modem
  WiFi.begin(ssid, password);

  // Check if Wi-Fi is connected
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected successfully");
  Serial.print("Got IP: ");
  Serial.println(WiFi.localIP()); // Show ESP32 IP on serial

  server.on("/", handle_root);
  server.begin();
  Serial.println("HTTP server started");
  delay(100);
}

void loop() {
  server.handleClient();
}

// HTML & CSS contents which display on web server
String HTML = "<!DOCTYPE html>\
<html>\
<body>\
<h1>Mi Primera Pagina con ESP32 - Station Mode &#128522;</h1>\
</body>\
</html>";

// Handle root URL (/)
void handle_root() {
  server.send(200, "text/html", HTML);
} // Se agregó la llave de cierre aquí



//2.
#include <WiFi.h>
#include <WebServer.h>


// SSID & Password
const char* ssid = "Nautilus"; // Ingresa tu SSID aquí
const char* password = "20000Leguas"; // Ingresa tu contraseña aquí


WebServer server(80);


void handle_root();


void setup() {
  Serial.begin(115200);
  Serial.println("Intentando conectar a ");
  Serial.println(ssid);


  WiFi.begin(ssid, password);


  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }


  Serial.println("\nConexión WiFi exitosa");
  Serial.print("IP obtenida: ");
  Serial.println(WiFi.localIP());


  server.on("/", handle_root);
  server.begin();
  Serial.println("Servidor HTTP iniciado");
  delay(100);
}


void loop() {
  server.handleClient();
}


String HTML = "<!DOCTYPE html>\
<html>\
<head>\
    <title>TayoTube - ESP32</title>\
    <style>\
        * {\
            margin: 0;\
            padding: 0;\
            box-sizing: border-box;\
        }\
        body {\
            font-family: 'Arial', sans-serif;\
            background: linear-gradient(135deg, #ff5e62, #ff9966);\
            color: white;\
            display: flex;\
            flex-direction: column;\
            align-items: center;\
            justify-content: center;\
            min-height: 100vh;\
            text-align: center;\
            padding: 0 20px;\
        }\
        h1 {\
            font-size: 3em;\
            font-weight: bold;\
            background-color: rgba(0, 0, 0, 0.5);\
            padding: 20px 40px;\
            border-radius: 15px;\
            margin-bottom: 30px;\
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);\
        }\
        #changeButton {\
            font-size: 1.5em;\
            padding: 12px 30px;\
            background-color: #ffcc00;\
            color: black;\
            border: none;\
            border-radius: 50px;\
            cursor: pointer;\
            margin-top: 30px;\
            transition: all 0.3s;\
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);\
        }\
        #changeButton:hover {\
            background-color: #ff9966;\
            transform: scale(1.1);\
        }\
        .video-container {\
            display: grid;\
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));\
            gap: 20px;\
            margin-top: 40px;\
            max-width: 1000px;\
            width: 100%;\
        }\
        video {\
            width: 100%;\
            border-radius: 15px;\
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.3);\
            transition: transform 0.3s, box-shadow 0.3s;\
        }\
        video:hover {\
            transform: scale(1.05);\
            box-shadow: 0px 12px 30px rgba(0, 0, 0, 0.4);\
        }\
        footer {\
            position: absolute;\
            bottom: 20px;\
            font-size: 1em;\
            color: rgba(255, 255, 255, 0.7);\
        }\
        footer a {\
            color: #ffcc00;\
            text-decoration: none;\
        }\
        footer a:hover {\
            color: #ff9966;\
        }\
    </style>\
</head>\
<body>\
    <h1>Bienvenido a TayoTube</h1>\
    <p>Disfruta de los videos y cambia aleatoriamente</p>\
    <button id=\"changeButton\" onclick=\"changeVideos()\">Cambiar Videos</button>\
    <div class=\"video-container\">\
        <video id=\"video1\" controls autoplay loop>\
            <source src=\"https://www.w3schools.com/html/mov_bbb.mp4\" type=\"video/mp4\">\
            <img class=\"media\" src=\"https://upload.wikimedia.org/wikipedia/commons/4/4f/Random_image.svg\" alt=\"Video no disponible\">\
        </video>\
        <video id=\"video2\" controls autoplay loop>\
            <source src=\"https://www.w3schools.com/html/movie.mp4\" type=\"video/mp4\">\
            <img class=\"media\" src=\"https://upload.wikimedia.org/wikipedia/commons/4/4f/Random_image.svg\" alt=\"Video no disponible\">\
        </video>\
        <video id=\"video3\" controls autoplay loop>\
            <source src=\"https://www.w3schools.com/html/mov_bbb.ogg\" type=\"video/ogg\">\
            <img class=\"media\" src=\"https://upload.wikimedia.org/wikipedia/commons/4/4f/Random_image.svg\" alt=\"Video no disponible\">\
        </video>\
        <video id=\"video4\" controls autoplay loop>\
            <source src=\"https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4\" type=\"video/mp4\">\
            <img class=\"media\" src=\"https://upload.wikimedia.org/wikipedia/commons/4/4f/Random_image.svg\" alt=\"Video no disponible\">\
        </video>\
        <video id=\"video5\" controls autoplay loop>\
            <source src=\"https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4\" type=\"video/mp4\">\
            <img class=\"media\" src=\"https://upload.wikimedia.org/wikipedia/commons/4/4f/Random_image.svg\" alt=\"Video no disponible\">\
        </video>\
        <video id=\"video6\" controls autoplay loop>\
            <source src=\"https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4\" type=\"video/mp4\">\
            <img class=\"media\" src=\"https://upload.wikimedia.org/wikipedia/commons/4/4f/Random_image.svg\" alt=\"Video no disponible\">\
        </video>\
    </div>\
    <footer>\
        <p>Desarrollado por <a href=\"https://www.esp32.com\" target=\"_blank\">ESP32</a></p>\
    </footer>\
    <script>\
        let changeCount = 0;\
        function changeVideos() {\
            if (changeCount >= 5) return;\
            const videos = [\
                'https://www.w3schools.com/html/mov_bbb.mp4',\
                'https://www.w3schools.com/html/movie.mp4',\
                'https://www.w3schools.com/html/mov_bbb.ogg',\
                'https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4',\
                'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',\
                'https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4'\
            ];\
            for (let i = 1; i <= 6; i++) {\
                const randomVideo = videos[Math.floor(Math.random() * videos.length)];\
                document.getElementById('video' + i).querySelector('source').src = randomVideo;\
                document.getElementById('video' + i).load();\
            }\
            changeCount++;\
        }\
    </script>\
</body>\
</html>";


void handle_root() {
  server.send(200, "text/html", HTML);
}


